// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef LITE_POLICY_H_INCLUDED
#define LITE_POLICY_H_INCLUDED

#include "incremental_policy.h"
#include "policy_quiet.h"

namespace Stockfish {

class LitePolicy {
   public:
    bool start(const std::string& path, std::string& error) {
        enabled = !path.empty() && model.load(path, error);
        cache.prepare(enabled, model.generation());
        model.reset();
        work = calls = 0;
        return enabled;
    }

    void clear() { cache.reset(enabled); }
    bool active() const { return enabled; }
    u64 inferences() const { return calls; }
    void push() { if (enabled) model.push(); }
    void pop() { if (enabled) model.pop(); }

    void order(const Position& position, ExtMove* begin, ExtMove* end, Move ttMove,
               int threshold, u64 nodes, bool allowInference) {
        const Key key = position.key();
        const u64 allowance = quiet_policy_allowance(nodes);
        if (!cache.contains(key)
            && (!allowInference || work + quiet_policy_cost(model.width(), 2) > allowance))
            return;

        QuietPolicyCandidates candidates;
        candidates.collect(begin, end, ttMove, threshold);
        if (candidates.count < 2) return;
        std::array<bool, QuietPolicyCandidates::Limit> missing{};
        const int count = cache.get_candidates(key, candidates, missing);
        const u64 cost = quiet_policy_cost(model.width(), count);
        if (count && (!allowInference || work + cost > allowance)) return;
        if (count) {
            const auto hidden = model.context(position);
            std::array<Move, QuietPolicyCandidates::Limit> moves;
            std::array<float, QuietPolicyCandidates::Limit> logits;
            int output = 0;
            for (int i = 0; i < candidates.count; ++i)
                if (missing[i]) moves[output++] = *candidates.slots[i];
            model.scores(hidden, moves.data(), logits.data(), output, position);
            work += cost;
            ++calls;
            output = 0;
            for (int i = 0; i < candidates.count; ++i)
                if (missing[i]) {
                    const float logit = logits[output++];
                    candidates.logits[i] = logit;
                    cache.put(key, *candidates.slots[i], logit);
                }
        }
        candidates.promote(1.0f);
    }

   private:
    IncrementalPolicy model;
    QuietPolicyCache cache;
    bool enabled = false;
    u64 work = 0, calls = 0;
};

} // namespace Stockfish
#endif
